// parse document and optimize elements
// it will only enable features defined in options.
ext_fixfixed.ready(window);
